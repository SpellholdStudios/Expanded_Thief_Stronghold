Small 'cheat' script allowing a non-thief character to gain the Thief Stronghold.

Instructions:

1. Place script in the /scripts/ directory.
2. Accept the reward from Renal as you normally would. 
   While still in the Shadow Thief Guild, just after talking to Renal, follow the steps below:

3. Assign the script to a character.
4. Turn the AI on (if it's off).
5. Firmly tap the 'E' key.

GB <g_blucher@yahoo.com>